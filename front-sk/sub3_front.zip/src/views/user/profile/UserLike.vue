<template>
    <div>
        <h1>안녕 여긴 좋아요</h1>
        <allLike></allLike>
    </div>  
</template>

<script>
import allLike from "../../../components/common/allLike"


export default {
    components:{
        allLike
    }

};
</script>
