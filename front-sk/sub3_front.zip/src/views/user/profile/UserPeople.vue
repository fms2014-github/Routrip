<template>
    <div>
        <h1>안녕 여긴 빨로팔롱잉</h1>
        <allPeople></allPeople>
    </div>
</template>

<script>
import allPeople from "../../../components/common/allPeople"

export default {
    components: {
        allPeople
    }
};
</script>
