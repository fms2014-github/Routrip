<template>
    <div>
        <!-- <h1>안녕 여긴 댓글</h1> -->
        <allComment></allComment>
    </div>
</template>

<script>
import allComment from "../../../components/common/allComment"

export default {
    components:{
        allComment
    }
}




</script>
