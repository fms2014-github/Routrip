// Vue 및 테스트할 컴포넌트 가져오기
import Vue from 'vue';
import ExampleModel from '../../model/ExampleModel';
/*
기본적인 Jest 테스트 구문입니다.


https://kr.vuejs.org/v2/guide/unit-testing.html
공식문서를 확인하고 Test 코드를 작성하세요.

 */

describe('테스트 분류를 적습니다', () => {
    // 원시 컴포넌트 옵션을 검사합니다.
    it('테스트 기능을 적습니다', () => {
        expect(true).toBe(true);
    });
});
