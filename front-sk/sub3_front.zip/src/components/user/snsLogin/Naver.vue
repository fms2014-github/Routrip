<template>
    <div id="naver-login">
        <button>
            <svg xmlns="http://www.w3.org/2000/svg" width="55" height="55" viewBox="0 0 55 55">
                <g id="구성_요소_3" data-name="구성 요소 3">
                    <g id="타원_6" data-name="타원 6" fill="#4FA42B" stroke="#eee" stroke-width="1">
                        <circle cx="27.5" cy="27.5" r="27.5" stroke="none" />
                        <circle cx="27.5" cy="27.5" r="27" fill="none" />
                    </g>
                </g>
                <path
                    id="path2830"
                    d="M102.713,153.188l-.064,19.63,7.719.032V162.465l6.829,10.354,7.751.064-.032-19.63-7.751-.032-.019,10.271L110.4,153.22Z"
                    transform="translate(-86.649 -135.188)"
                    fill="#fff"
                />
            </svg>
        </button>
    </div>
</template>

<script>
export default {};
</script>
