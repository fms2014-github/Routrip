<template>
    <div class="google-login">
        <button @click="googleLogin">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="55" height="55" viewBox="0 0 55 55">
                <defs>
                    <clipPath id="clip-path">
                        <path
                            id="패스_155"
                            data-name="패스 155"
                            d="M21.023,10.057H11.847v3.8h5.282c-.492,2.417-2.551,3.8-5.282,3.8a5.819,5.819,0,1,1,0-11.637,5.693,5.693,0,0,1,3.625,1.3l2.865-2.865a9.841,9.841,0,1,0-6.49,17.232c4.923,0,9.4-3.581,9.4-9.847A8.169,8.169,0,0,0,21.023,10.057Z"
                            transform="translate(-2 -2)"
                        />
                    </clipPath>
                </defs>
                <g id="그룹_248" data-name="그룹 248" transform="translate(-300 -406)">
                    <g id="타원_6" data-name="타원 6" transform="translate(300 406)" fill="#fff" stroke="#eee" stroke-width="1">
                        <circle cx="27.5" cy="27.5" r="27.5" stroke="none" />
                        <circle cx="27.5" cy="27.5" r="27" fill="none" />
                    </g>
                    <g id="Google__G__Logo" transform="translate(318 424)">
                        <g id="그룹_114" data-name="그룹 114" clip-path="url(#clip-path)">
                            <path
                                id="패스_154"
                                data-name="패스 154"
                                d="M0,22.637V11l7.609,5.819Z"
                                transform="translate(-0.895 -6.972)"
                                fill="#fbbc05"
                            />
                        </g>
                        <g id="그룹_115" data-name="그룹 115" clip-path="url(#clip-path)">
                            <path
                                id="패스_156"
                                data-name="패스 156"
                                d="M0,4.923l7.609,5.819,3.133-2.73L21.484,6.266V0H0Z"
                                transform="translate(-0.895 -0.895)"
                                fill="#ea4335"
                            />
                        </g>
                        <g id="그룹_116" data-name="그룹 116" clip-path="url(#clip-path)">
                            <path
                                id="패스_158"
                                data-name="패스 158"
                                d="M0,16.561,13.428,6.266l3.536.448L21.484,0V21.484H0Z"
                                transform="translate(-0.895 -0.895)"
                                fill="#34a853"
                            />
                        </g>
                        <g id="그룹_117" data-name="그룹 117" clip-path="url(#clip-path)">
                            <path
                                id="패스_160"
                                data-name="패스 160"
                                d="M28.666,27.561,14.79,16.819,13,15.476,28.666,11Z"
                                transform="translate(-8.077 -6.972)"
                                fill="#4285f4"
                            />
                        </g>
                    </g>
                </g>
            </svg>
        </button>
    </div>
</template>

<script>
export default {
    methods: {
        googleLogin() {
            console.log('this is google login');
            let uri =
                'https://accounts.google.com/o/oauth2/v2/auth?scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fcalendar.readonly%20https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fcalendar&access_type=offline&include_granted_scopes=true&state=state_parameter_passthrough_value&redirect_uri=http%3A%2F%2Flocalhost%3A3000&response_type=code&client_id=1096416330009-u6ca2mhsseo9i4nsvvsh4knvco4tjo30.apps.googleusercontent.com';
            location.href = uri;
        },
    },
};
</script>
