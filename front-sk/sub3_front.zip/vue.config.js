module.exports = {
    transpileDependencies: ['vuetify'],
};
