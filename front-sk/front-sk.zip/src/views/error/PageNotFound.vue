<template>
    <div id="not-found">
        <img src="../../assets/images/Not.png" />
        <h1>페이지를 찾을 수 없습니다.</h1>
        <h1>404 Not Found</h1>
    </div>
</template>

<script>
import '../../assets/css/error.scss';
export default {};
</script>
