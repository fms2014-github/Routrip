<template>
    <h1>안녕 여긴 좋아요</h1>
</template>

<script>
import UserApi from '../../../apis/UserApi';

export default {};
</script>
