<template>
    <div id="footer">
        <h1>푸터입니다.</h1>
    </div>
</template>

<script>
export default {};
</script>

<style>
</style>