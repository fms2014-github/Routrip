<template>
    <div id="header">
        <div class="hambuger">
            <i class="fas fa-bars"></i>
        </div>
        <div class="home">
            <img class="logo" src="../../assets/images/routrip_logo.png" />
            <span class="title">루트립</span>
        </div>
        <div class="menu">
            <span class="menu-icon"><i class="far fa-plus-square"></i></span>
            <span class="menu-icon"><i class="far fa-comment-alt"></i></span>
            <a href="#"><img class="profile-img" src="../../assets/images/user.png"/></a>
        </div>
    </div>
</template>

<script>
import '../../assets/css/main/header.scss';
export default {};
</script>
