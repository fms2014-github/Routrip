<template>
    <div class="best-posting-component">
        <div class="horizontal-scroll-wrapper">
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip1.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip2.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip3.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip4.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip5.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip1.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip2.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip3.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip4.jpg" />
                </a>
            </div>
            <div class="best-img">
                <a href>
                    <img src="../../assets/images/trip_img/trip5.jpg" />
                </a>
            </div>
        </div>
    </div>
</template>

<script>
export default {};
</script>

<style>
</style>